import { NgModule } from "@angular/core";//ng-app is called Ngmodule
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";//shadow dom copy
import { CommonModule } from "@angular/common";//supports depency injection,class,modules
import { MenuComponent } from "./menu/menu.component";
import { MenuService } from "./services/menuservice";
import { AppRoutingModule } from "./app.routing.module";
import { ClaimComponent } from "./claim/claim.component";
import { AssessorComponent } from "./assessor/assessor.component";
import { PaymentComponent } from "./payment/payment.component";
import { ClaimApprovalComponent } from "./claim/claim.claimapprovalcomponent";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {JsonpModule} from "@angular/http";
import {CityService} from "./services/cityservice";
import {HttpModule} from "@angular/http";
import {DataService} from "./services/dataservice";
import { ClaimService } from "./services/claimservice";

@NgModule({
    imports:[BrowserModule,CommonModule,AppRoutingModule,HttpModule,FormsModule,ReactiveFormsModule,JsonpModule],
    declarations:[AppComponent,MenuComponent,ClaimComponent,ClaimApprovalComponent,PaymentComponent,AssessorComponent],
    providers:[MenuService,CityService,DataService,ClaimService],
    bootstrap:[AppComponent]
})

export class AppModule
{

}