import { NgModule } from "@angular/core";
import { RouterModule,Routes } from "@angular/router";
import { ClaimComponent } from "./claim/claim.component";
import { AssessorComponent } from "./assessor/assessor.component";
import { PaymentComponent } from "./payment/payment.component";
import { ClaimApprovalComponent } from "./claim/claim.claimapprovalcomponent";
//routing of files


//map the path
const routes:Routes=[
    {
        path:'Claim_Intimation',//path name to be provided
        component:ClaimComponent//component created so it will load 
    },
    {
        path:'Assessor_Report',
        component:AssessorComponent
    },
    {
        path:'Payment',
       component:PaymentComponent
    },
    {
        path:'Claim_Approval',
        component:ClaimApprovalComponent
    }
];

@NgModule
({
    imports:[RouterModule.forRoot(routes)],//import for routes
    exports:[RouterModule]
})
export class AppRoutingModule
{

}
