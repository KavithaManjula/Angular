import { Component } from "@angular/core";

@Component(
    {
        selector:'payment',
        templateUrl:'./app/payment/payment.component.html',
        styleUrls:['./app/payment/payment.component.css']
    }
)
export class PaymentComponent
{

}