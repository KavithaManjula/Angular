var firstName:string;
var lastName:string;
var dob:Object;
var isEmployed:boolean;
var data:any;//supports all data types
var act:accountType;

firstName="kavitha"
lastName="krishnan"
isEmployed=true;
dob=new Date('1970-12-02');

data="class"
data=45456456
data=false;
data=new Date();

console.log(firstName,lastName,"having",dob,"is empployed",isEmployed);
console.log(data);

//enum data type
enum accountType
{
    SAVINGS,RECURRING,DEMAT,LOAN
}
act=accountType.DEMAT;
console.log("Account Type First=",act);//It will return 2 position of enum value demat

act=accountType.LOAN;
console.log("Account Type Second=",act);;//It will return 3 position of enum value loan

//Array data type
var insuranceTypes=["General","Life","Health","Auto","Eductaion","Marriage"];

//lamda operator or arrow function
insuranceTypes.forEach(obj=>
    {
        console.log(obj+" Insurance");
    })

//Void wont return any data
function  userData(fname:string,lname:string):void 
{
    console.log(fname+"--->"+lname);
}

userData("Kavi","kris");

//Return data 
function  userData2(fname:string,lname:string):string
{
    return(fname+"--->"+lname);
}
console.log(userData2("Aruna","Manju"));

//default parameters
function  userData3(fname:string,lname:string,country:string="India"):string
{
    return(fname+"--->"+lname+"belong to "+country);
}
console.log(userData3("Aruna","Manju","USA"));


//optional params
function getData(name:string,...skillset)//skillset is optional parameters (...skillset) means array
{
console.log(name,skillset);
}
getData("Appu");//without second parameters
getData("Appu","Java","C#","Python");//Three datas are passed in second parameters
getData("Jaya","Java");//One data are passed in second parameters
getData("Jaya",0,1,2);
getData("Jaya",0.0,1.23,"Welcome");
