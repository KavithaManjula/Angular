"use strict";
exports.__esModule = true;
var PolicyModule;
(function (PolicyModule) {
    var Vehicle = /** @class */ (function () {
        function Vehicle(pregNo, pmodel, pengineNo, pmfgDate, pcost) {
            this.regNo = pregNo;
            this.model = pmodel;
            this.engineNo = pengineNo;
            this.mfgDate = pmfgDate;
            this.onRoadCost = pcost;
        }
        Object.defineProperty(Vehicle.prototype, "RegNo", {
            get: function () {
                return this.regNo;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Vehicle.prototype, "Model", {
            //set RegNo(value:string)
            //{
            //  this.regNo=value;
            //}
            get: function () {
                return this.model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Vehicle.prototype, "EngineNo", {
            get: function () {
                return this.engineNo;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Vehicle.prototype, "MFGDate", {
            get: function () {
                return this.mfgDate;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Vehicle.prototype, "Owner", {
            // set MFGDate(value:object)
            //{
            //  this.mfgDate=value;
            //}
            get: function () {
                return this.owner;
            },
            set: function (value) {
                this.owner = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Vehicle.prototype, "OnRoadCost", {
            get: function () {
                return this.onRoadCost;
            },
            enumerable: true,
            configurable: true
        });
        return Vehicle;
    }());
    PolicyModule.Vehicle = Vehicle;
    var Policy = /** @class */ (function () {
        function Policy() {
        }
        Policy.getAddress = function () {
            return .Policy.companyAddress;
        };
        return Policy;
    }());
    PolicyModule.Policy = Policy;
    var PolicyHolder = /** @class */ (function () {
        function PolicyHolder() {
        }
        return PolicyHolder;
    }());
    PolicyModule.PolicyHolder = PolicyHolder;
})(PolicyModule = exports.PolicyModule || (exports.PolicyModule = {}));
//tsc --target ES2016 oopsdemo.ts(For Higher Standard Implementation)
//var vehicleObj:Vehicle=new Vehicle('TN-06-4218','TVS','ABCD90323423',new Date('2016-06-27'),523000);
//vehicleObj.Owner="Aruna";//value may change so it used get set methods
//vehicleObj.RegNo="TN-06-4218";
//vehicleObj.Model="TVS";
//vehicleObj.EngineNo="ABCD90323423";
//vehicleObj.MFGDate=new Date('2016-06-27');
//console.log(vehicleObj.Owner,'-',vehicleObj.RegNo,'-',vehicleObj.Model,'-',vehicleObj.EngineNo,'-',vehicleObj.MFGDate,'-',
//vehicleObj.OnRoadCost);
