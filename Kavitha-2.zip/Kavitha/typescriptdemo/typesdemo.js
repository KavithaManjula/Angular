var firstName;
var lastName;
var dob;
var isEmployed;
var data; //supports all data types
var act;
firstName = "kavitha";
lastName = "krishnan";
isEmployed = true;
dob = new Date('1970-12-02');
data = "class";
data = 45456456;
data = false;
data = new Date();
console.log(firstName, lastName, "having", dob, "is empployed", isEmployed);
console.log(data);
//enum data type
var accountType;
(function (accountType) {
    accountType[accountType["SAVINGS"] = 0] = "SAVINGS";
    accountType[accountType["RECURRING"] = 1] = "RECURRING";
    accountType[accountType["DEMAT"] = 2] = "DEMAT";
    accountType[accountType["LOAN"] = 3] = "LOAN";
})(accountType || (accountType = {}));
act = accountType.DEMAT;
console.log("Account Type First=", act); //It will return 2 position of enum value demat
act = accountType.LOAN;
console.log("Account Type Second=", act);
; //It will return 3 position of enum value loan
//Array data type
var insuranceTypes = ["General", "Life", "Health", "Auto", "Eductaion", "Marriage"];
//lamda operator or arrow function
insuranceTypes.forEach(function (obj) {
    console.log(obj + " Insurance");
});
//Void wont return any data
function userData(fname, lname) {
    console.log(fname + "--->" + lname);
}
userData("Kavi", "kris");
//Return data 
function userData2(fname, lname) {
    return (fname + "--->" + lname);
}
console.log(userData2("Aruna", "Manju"));
//default parameters
function userData3(fname, lname, country) {
    if (country === void 0) { country = "India"; }
    return (fname + "--->" + lname + "belong to " + country);
}
console.log(userData3("Aruna", "Manju", "USA"));
//optional params
function getData(name) {
    var skillset = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        skillset[_i - 1] = arguments[_i];
    }
    console.log(name, skillset);
}
getData("Appu");
getData("Appu", "Java", "C#", "Python");
getData("Jaya", "Java");
getData("Jaya", 0, 1, 2);
getData("Jaya", 0.0, 1.23, "Welcome");
