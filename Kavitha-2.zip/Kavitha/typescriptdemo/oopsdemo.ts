export module PolicyModule
{
    export  class Vehicle
    {
        private regNo:string;
        private model:string;
        private engineNo:string;
        private mfgDate:object;
        private onRoadCost:number;
        private owner:string;
        constructor(pregNo:string,pmodel:string,pengineNo:string,pmfgDate:object,pcost:number)//constructor where data to be intialized 
        {
            this.regNo=pregNo;
            this.model=pmodel;
            this.engineNo=pengineNo;
            this.mfgDate=pmfgDate;
            this.onRoadCost=pcost;
        }
        get RegNo():string
        {
            return this.regNo;
        }
        //set RegNo(value:string)
        //{
        //  this.regNo=value;
        //}
        get Model():string
        {
            return this.model;
        }
        
        get EngineNo():string
        {
            return this.engineNo;
        }
        get MFGDate():object
        {
            return this.mfgDate;
        }
        // set MFGDate(value:object)
        //{
        //  this.mfgDate=value;
        //}
        get Owner():string
        {
            return this.owner;
        }
        set Owner(value:string)
        {
            this.owner=value;
        }
        get OnRoadCost():number
        {
            return this.onRoadCost;
        }
    }
    export class Policy
    {
        public static  companyAddress:string;//static variable
        static getAddress():string//static method
        {
            return.Policy.companyAddress;
        }
    }
    
    export class PolicyHolder
    {
        private polichilde:string;
    }
}

//tsc --target ES2016 oopsdemo.ts(For Higher Standard Implementation)
//var vehicleObj:Vehicle=new Vehicle('TN-06-4218','TVS','ABCD90323423',new Date('2016-06-27'),523000);
//vehicleObj.Owner="Aruna";//value may change so it used get set methods
//vehicleObj.RegNo="TN-06-4218";
//vehicleObj.Model="TVS";
//vehicleObj.EngineNo="ABCD90323423";
//vehicleObj.MFGDate=new Date('2016-06-27');
//console.log(vehicleObj.Owner,'-',vehicleObj.RegNo,'-',vehicleObj.Model,'-',vehicleObj.EngineNo,'-',vehicleObj.MFGDate,'-',
//vehicleObj.OnRoadCost);
