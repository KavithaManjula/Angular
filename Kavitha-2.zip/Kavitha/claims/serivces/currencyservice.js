claimApp.service('CurrencyService',['$http',function($http)
{
 var currencyList=function()
 {
     return $http
     ({
         url:"https://restcountries.eu/rest/v2/all",
         method:"GET",
         datatype:"jsonp",
         headers:
         {
                'Content-Type':'application/json'
         }
     });
}
    return{
        currencyObj:currencyList 
    }
}])