import { NgModule } from "@angular/core";//ng-app is called Ngmodule
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";//shadow dom copy
import { CommonModule } from "@angular/common";//supports depency injection,class,modules

//what components are going to use
@NgModule
({
    imports:[BrowserModule,CommonModule],
    declarations:[AppComponent],
    bootstrap:[AppComponent] //main component to be called refered to  app.component.ts
})

export class AppModule
{

}