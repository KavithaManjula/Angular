import {Component} from "@angular/core"

//creation of component
@Component({
            selector:'gic-home',//tag creation
            template:`<img src="{{imgPath}}">`,//property binding to template
            styleUrls:['./app/app.component.css']//It refers to css file

        })

export class AppComponent
{
    private imgPath:string;//imagepath is refered to template
    constructor()
    {
        this.imgPath="./images/logo.png";//url to be mentioned for the image path
    }
}