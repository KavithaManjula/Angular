claimApp.controller('CurrencyController',['$scope','CurrencyService',function($scope,CurrencyService)
{
    CurrencyService.currencyObj().then(function(response)
    {
        console.log(response);
        $scope.currency=response.data;
    })

}])

