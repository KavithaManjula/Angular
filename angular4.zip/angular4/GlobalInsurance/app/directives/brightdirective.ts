import { Directive, ElementRef } from "@angular/core";

@Directive({
    selector:'[bright]'
})
export class  BrightDirective
{
    constructor(private e1:ElementRef)
    {
        e1.nativeElement.nodeName.style.backgroudColor="red";
        if(e1.nativeElement.nodeName=="div")
        {
            e1.nativeElement.nodeName.style.backgroudColor="red";
        }
        if(e1.nativeElement.nodeName=="DIV")
        {
            e1.nativeElement.nodeName.style.backgroudColor="red";
        }
    }
}