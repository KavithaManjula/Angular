import { NgModule } from "@angular/core";//ng-app is called Ngmodule
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";//shadow dom copy
import { CommonModule } from "@angular/common";//supports depency injection,class,modules
import { MenuComponent } from "./menu/menu.component";
import { MenuService } from "./services/menuservice";
import { AppRoutingModule } from "./app.routing.module";
import { ClaimComponent } from "./claim/claim.component";
import { AssessorComponent } from "./assessor/assessor.component";
import { PaymentComponent, ChequeDialog, CashDialog } from "./payment/payment.component";
import { ClaimApprovalComponent } from "./claim/claim.claimapprovalcomponent";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {JsonpModule} from "@angular/http";
import {CityService} from "./services/cityservice";
import {HttpModule} from "@angular/http";
import {DataService} from "./services/dataservice";
import { ClaimService } from "./services/claimservice";
import { PolicyService } from "./services/policyservice";
import {
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
  } from '@angular/material';
import { BrightDirective } from "./directives/brightdirective";

@NgModule({
    imports:[BrowserModule,CommonModule,AppRoutingModule,HttpModule,FormsModule,ReactiveFormsModule,JsonpModule
    ,MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,],
    declarations:[
                    AppComponent,MenuComponent,ClaimComponent,ClaimApprovalComponent,PaymentComponent,
                    AssessorComponent,ChequeDialog,CashDialog,BrightDirective
                ],
    providers:[MenuService,CityService,DataService,ClaimService,PolicyService,PaymentComponent,ChequeDialog,CashDialog],
    bootstrap:[AppComponent]
})

export class AppModule
{

}