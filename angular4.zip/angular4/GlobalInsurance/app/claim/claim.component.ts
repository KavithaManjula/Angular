import {Component, OnInit} from "@angular/core";
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {CityService} from "../services/cityservice";
import {Observable} from 'rxjs';
import {DataService} from "../services/dataservice";
import {Country} from "../models/country";
import {State} from "../models/state";
import { ClaimService } from "../services/claimservice";
@Component({
    selector:'claim-intimation',
    templateUrl:'./app/claim/claim.component.html',
    styleUrls:['./app/claim/claim.component.css']
})
export class ClaimComponent implements OnInit
{
    private items: Observable<Array<string>>;//observable based on the typing word
    private claimForm:FormGroup;
    private policyNo:FormControl;
    private engineNo:FormControl;
    private intimationDate:FormControl;
    private state:FormControl;
    private country:FormControl;
    private location:FormControl;
    private driverName:FormControl;
    private driverLicense:FormControl;
    errorMessage:string;

    selectedCountry:Country = new Country(0, 'India');
    countries: Country[];
    statesArr: State[];
    constructor(
        private formBuilder:FormBuilder,private router:Router,private _dataService: DataService,
        private cityService:CityService,
        private claimservice:ClaimService
    )
    {
       this.policyNo=new FormControl('',[Validators.required,
           Validators.pattern('[0-9/]{15,20}')
       ]);
       this.engineNo=new FormControl('',[Validators.required,
       Validators.pattern('[A-Za-z0-9]{5,10}')]);
       this.intimationDate=new FormControl('',[Validators.required]);
       this.driverName=new FormControl('',
           [Validators.required,Validators.pattern('[A-Za-z]{5,25}')]);
        this.state=new FormControl('',
            [Validators.required,Validators.pattern('[A-Za-z]{3,25}')]);
        this.country=new FormControl('',
        [Validators.required,Validators.pattern('[A-Za-z]{3,25}')]);
        this.location=new FormControl('',
            [Validators.required,Validators.pattern('[A-Za-z]{5,25}')]);
        this.driverLicense=new FormControl('',
            [Validators.required,Validators.pattern('[A-Za-z0-9]{5,25}')]);

        this.claimForm=formBuilder.group({
            policyNo:this.policyNo,
            engineNo:this.engineNo,
            intimationDate:this.intimationDate,
            driverName:this.driverName,
            state:this.state,
            country:this.country,
            location:this.location,
            driverLicense:this.driverLicense
        })

    }

    ngOnInit() {
        this.countries = this._dataService.getCountries();
        console.log(this.location.value);
        this.items = this.location.valueChanges
            .debounceTime(400)
            .distinctUntilChanged()
            .switchMap(term => this.cityService.getCityDetails(term));
            console.log(this.items);
    }
    onSelect(countryid) {
        console.log(countryid);
        this.statesArr = this._dataService.getStates().filter((item)=> item.countryid == countryid);
        console.log(this.statesArr);
    }
    save()
    {
        console.log(this.claimForm.value);
        this.claimservice.submitClaim(this.claimForm.value).then(res=>{
                console.log(res);
        },//this is return the data to server side
        error=>this.errorMessage=<any>error);
    }
}