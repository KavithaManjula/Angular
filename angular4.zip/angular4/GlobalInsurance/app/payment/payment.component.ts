import { Component, Inject } from "@angular/core";
import { PolicyService } from "../services/policyservice";
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component(
    {
        selector:'payment',
        templateUrl:'./app/payment/payment.component.html',
        styleUrls:['./app/payment/payment.component.css']
    }
)
export class PaymentComponent
{
    private policies:any;
    private selectedMode:string="cheque";
    private amount:number;
    private chequeNo:number;
    paymentoptions =['cheque','cash'];//radio button selection
    
    constructor(private policyService:PolicyService,private matDialog:MatDialog)
    {

    }
    ngOnInit()
    {
        this.policies=this.policyService.getPolicies();
    }
    openDialog(value):void
    {
        if (value!='undefined')
        {
            console.log(value);
            if(value=="cheque")
            {
                let dialogRef = this.matDialog.open(ChequeDialog,    
                {
                    width: '250px',
                    data: {chequeNo:this.chequeNo,amount:this.amount}
                });
                dialogRef.afterClosed().subscribe(result => {
                    console.log('The dialog was closed');
                    this.amount = result;
                });
            }
            if (value=="cash")
            {
                let dialogRef = this.matDialog.open(CashDialog,
                {
                    width: '250px',
                    data: {amount:this.amount}
                });
                dialogRef.afterClosed().subscribe(result => {
                    console.log('The dialog was closed');
                    this.amount = result;
                });
            }
        }
    }
}

@Component({
    selector: 'dialog-overview-example-dialog',
    templateUrl: './app/payment/cheque-Dialog.html',
})
export class ChequeDialog {

    constructor(
        public dialogRef: MatDialogRef<ChequeDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

}
@Component({
    selector: 'dialog-overview-example-dialog',
    templateUrl: './app/payment/cash-Dialog.html',
})
export class CashDialog {

    constructor(
        public dialogRef: MatDialogRef<CashDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

}