import {Policy} from "../models/policy";
import {Injectable} from "@angular/core";

@Injectable()
export class PolicyService {
    getPolicies() {
        return [
            new Policy('56/567/56756/567',1000),
            new Policy('8659/567/56756/567',2000),
            new Policy('456/567/567',3000),
            new Policy('678/567/567',4000)
        ];
    }

}
