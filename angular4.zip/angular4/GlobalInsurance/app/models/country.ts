export class Country//Country TS
{
    constructor(public id:number,public name:string)
    {

    }
}