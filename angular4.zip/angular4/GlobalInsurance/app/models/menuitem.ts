export class MenuItem//creating menu item dynamically
{
    private itemCode:number;
    private itemName:string;
    constructor(code:number,name:string)
    {
        this.itemCode=code;
        this.itemName=name;
    }
}