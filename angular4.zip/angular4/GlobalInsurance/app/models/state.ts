export class State//State TS
{
    constructor(public id:number,public countryid:number,public name:string)
    {
        
    }
}