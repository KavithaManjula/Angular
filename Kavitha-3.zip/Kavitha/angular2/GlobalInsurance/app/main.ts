//what modules youring run time/git browser dynamic
import {platformBrowserDynamic} from "@angular/platform-browser-dynamic";//platform browser dynami is for compilation JIT
import {AppModule} from "./app.module";

platformBrowserDynamic().bootstrapModule(AppModule);
