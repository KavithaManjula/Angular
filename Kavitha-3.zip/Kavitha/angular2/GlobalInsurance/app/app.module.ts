import { NgModule } from "@angular/core";//ng-app is called Ngmodule
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";//shadow dom copy
import { CommonModule } from "@angular/common";//supports depency injection,class,modules
import { MenuComponent } from "./menu/menu.component";
import { MenuService } from "./services/menuservice";
import { AppRoutingModule } from "./app.routing.module";
import { ClaimComponent } from "./claim/claim.component";
import { AssessorComponent } from "./assessor/assessor.component";
import { PaymentComponent } from "./payment/payment.component";
import { ClaimApprovalComponent } from "./claim/claim.claimapprovalcomponent";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

//what components are going to use
@NgModule
({
    imports:[BrowserModule,CommonModule,AppRoutingModule,FormsModule,ReactiveFormsModule],
    declarations:[AppComponent,MenuComponent,ClaimComponent,AssessorComponent,PaymentComponent,ClaimApprovalComponent],//menucomponent from menu.component.ts
    providers:[MenuService],
    bootstrap:[AppComponent] //main component to be called refered to  app.component.ts
})

export class AppModule
{

}