
//These are child components of app.component menu item
import { Component,OnInit } from "@angular/core";
import { MenuService } from "../services/menuservice";

@Component({
    selector:'claim-menu',
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css']

})
export class MenuComponent implements OnInit //OnInit contains the class ngOnInit
{
   
    private menu:any;//to get the menu items

    constructor(private menuServiceObj:MenuService)
    {
       
    }
    //after component initialiaztion invoke the life cycle method
    ngOnInit()//life cycle method (Life Cycle Hooks)
    {
        
        this.menu=this.menuServiceObj.getMenuData();//push the value to menu 
    }   
}