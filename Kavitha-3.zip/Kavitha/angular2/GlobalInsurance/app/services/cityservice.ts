import { Injectable } from "@angular/core";
import {URLSearchParams,Jsonp} from "@angular/http";
import { serializePath } from "@angular/router/src/url_tree";
import 'rxjs'


@Injectable()
export class CityService{

    constructor(private jsonp:Jsonp)
    {

    }
    public getCityDetails(term:string)
    {
        //  var search=new URLSearchParams();
        //search.set('search',term) ;
        //search.set('format','json');
        return this.jsonp
        .get("http://gd.geobytes.com/AutoCompleteCity?callback=?&q="+term)
        .map ((request)=>request.json()[1]);
        
    }
}