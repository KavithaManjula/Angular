interface Lakes//interface is used
{
    name: string;
    area:number;
    length:number;
    depth:number;
    isFreshwater:boolean;
    countries:string[];
    frozen?:string[];//? optional parameter
}

let firstLake:Lakes=//interface is implemented without object creadtion(field constants)
{
    name:'caspian',
     area:345353,
    length:3434,
    depth:343434,
    isFreshwater:false,
    countries:['Iran','India'],
    frozen:['yes']//data which is supplied is optional

}

let secondLake:Lakes=//interface is implemented without object creadtion
{
    name:'Arabian',
    area:5555,
    length:666,
    depth:777,
    isFreshwater:false,
    countries:['Iran','India']
}

//interface with methods
interface distance
{
    fromDistance:number;
    toDistance:number;
    computeDistance:()=>number;
    computeRelation:()=>string;
}

//read  only
interface Enemy
{
    readonly size:number,
    health:number;
    range:distance,
    readonly damage:number;
}
let distobj:distance={fromDistance:56,toDistance:130,
    computeDistance: ():number =>{return 100},
    computeRelation: ():string =>{return ("computed")}
};

//annonymous instance
let tank: Enemy = {
    size: 50,
    health: 100,
    range: distobj,
    damage: 12
}

console.log('Tank details...','-->',tank);

tank.health = 95;
console.log('After modifying Tank details...','-->',tank);
console.log(firstLake.name);
console.log(firstLake.countries);
console.log(firstLake.frozen);
console.log(secondLake.name,secondLake.countries);


interface Human
{
    firstName: string;
    lastName: string;
    name?: Function;///optional function
    isLate?(time: Date): Function;//optional function
}

class Person implements Human //person implements the interface human
{
    constructor(public firstName, public lastName) 
    {
    }
    public name()
    {
        return `${this.firstName} ${this.lastName}`;
    }
    protected whoAreYou() 
    {
        return `Hi i'm ${this.name()}`;
    }
}

class Student extends Person 
    {
    constructor(public firstName, public lastName, public course) 
    {
        super(firstName, lastName);
    }
    whoAreYou() 
    {
       return `${super.whoAreYou()} and i'm studying ${this.course}`;
       //return `${this.course}`
    }
    public name()
    {
        return `${this.firstName}`
    }
}
let asim = new Student("Asim", "Hussain", "typescript");
console.log(asim.whoAreYou());

let chk = new Student("hello", "welcome", "typescript");
console.log(chk.name());

let personobj=new Person("Aruna","krish")
console.log(personobj.name());
