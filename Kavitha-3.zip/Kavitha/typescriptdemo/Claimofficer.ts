import {InsuranceUser} from './user'//for inherting the InsuranceUser to claim officer class
import {PolicyModule} from './oopsdemo'//module imported

class ClaimOfficer extends InsuranceUser//Insurance extended to claimofficer
{
    private approval:boolean;
}

var claimOfficerObj:ClaimOfficer=new ClaimOfficer("Kavitha","kavitha@gmail.com","abc@123","Date of birth","06-05-1992");
console.log(claimOfficerObj.Name);
console.log(claimOfficerObj.Email);

var policyObj:PolicyModule.Policy=new PolicyModule.Policy();
PolicyModule.Policy.companyAddress="Address";
console.log(PolicyModule.Policy.getAddress());