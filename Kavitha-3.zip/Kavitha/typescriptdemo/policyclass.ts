class PolicyNo
{
    private policyNo:string;
    private claimId:number;
    private cliamDate:object
    constructor(ppolicyNO:string)
    {
            this.policyNo=ppolicyNO;
    }
    get ClaimId():number
    {
        return this.claimId;
    }
    set ClaimId(value:number)
    {
         this.claimId=value;
    }
}

var polichobj:PolicyNo =new PolicyNo("PO:345345")
