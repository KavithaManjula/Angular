"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var user_1 = require("./user"); //for inherting the InsuranceUser to claim officer class
var oopsdemo_1 = require("./oopsdemo"); //module imported
var ClaimOfficer = /** @class */ (function (_super) {
    __extends(ClaimOfficer, _super); //Insurance extended to claimofficer
    function ClaimOfficer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ClaimOfficer;
}(user_1.InsuranceUser //Insurance extended to claimofficer
));
var claimOfficerObj = new ClaimOfficer("Kavitha", "kavitha@gmail.com", "abc@123", "Date of birth", "06-05-1992");
console.log(claimOfficerObj.Name);
console.log(claimOfficerObj.Email);
var policyObj = new oopsdemo_1.PolicyModule.Policy();
oopsdemo_1.PolicyModule.Policy.companyAddress = "Address";
console.log(oopsdemo_1.PolicyModule.Policy.getAddress());
