"use strict";
exports.__esModule = true;
var InsuranceUser //base class
 = /** @class */ (function () {
    function InsuranceUser(pname, pemail, pwd, sq, sa) {
        this.name = pname;
        this.email = pemail;
        this.password = pwd;
        this.securityQuestion = sq;
        this.securityAnswer = sa;
    }
    Object.defineProperty(InsuranceUser.prototype, "Name", {
        get: function () {
            return this.name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InsuranceUser.prototype, "Email", {
        get: function () {
            return this.email;
        },
        enumerable: true,
        configurable: true
    });
    return InsuranceUser;
}());
exports.InsuranceUser = InsuranceUser;
