export class InsuranceUser//base class
{
    private name:string;
    private email:string;
    private password:string;
    private securityQuestion:string;
    private securityAnswer:string;
    constructor(pname:string,pemail:string,pwd:string,sq:string,sa:string)
    {
        this.name=pname;
        this.email=pemail;
        this.password=pwd;
        this.securityQuestion=sq;
        this.securityAnswer=sa;
    }
    get Name():string
    {
        return this.name;
    }
    get Email():string
    {
        return this.email;
    }
}