claimApp.controller('ClaimController',['$scope',function($scope)//name of the conntroller ClaimController and scope is the injector
{
    $scope.vehicleobj=//creating scope objects for the modules
    {
        regnNo:"",
        model:"",
        engineNo:""
    }
    $scope.policyHolderObj=
    {
        aadharCardNo:0,
        firstname:"",
        lastname:"",
        mobileno:0

    }
    $scope.policyobj=
    {
        policyNo:0,
        vehicle:$scope.vehicleobj,//scope inherits the vehicle object
        policyHolder:$scope.policyHolderObj//scope inherits the policyHolder object
    }
    $scope.claimObj=
    {
        policyNo:0,
        claimId:0,
        claimDate:new Date()
    }
    $scope.claimSubmit=function()//ng submit function to print 
    {

        console.log($scope.claimObj);//on submit button click the data entered in the form get printed in console app
        console.log($scope.policyobj);//on submit button click the data entered in the form get printed in console app

    }

}])